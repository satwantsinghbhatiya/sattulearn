<?php

namespace Drupal\custom_text\Plugin\Block;


use Drupal\Core\Block\BlockBase;


/**
 * Provides a 'custom text ' block.
 *
 * @Block(
 *   id = "custom_text_block",
 *   admin_label = @Translation("Custom text blo")
 * )
 */
class CustomTextBlock extends BlockBase  {

  
  /**
   * {@inheritdoc}
   */
  public function build() {
    $items = ['himmat','kimmat','satwant'];
    $heading_text = "This is heading";
    return [
        '#theme' => 'custom_item_list',
        '#items' => $items,
        '#heading' => $heading_text,
        '#attached' => array(
          'library' => array('custom_text/custom_text.text'),
        ),
    ];
  }

}
